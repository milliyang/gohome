// pngresize project doc.go

/*
pngresize document
*/
package main
